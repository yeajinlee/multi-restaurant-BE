package com.spring.project2_test.reconList.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;

public interface ReconListController {

	
	
public ModelAndView reconList(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
}
