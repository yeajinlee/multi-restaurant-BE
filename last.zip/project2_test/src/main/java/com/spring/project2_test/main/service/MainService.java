package com.spring.project2_test.main.service;

import java.util.List;

public interface MainService {

	public List restList() throws Exception;



}
