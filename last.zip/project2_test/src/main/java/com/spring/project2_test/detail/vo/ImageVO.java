package com.spring.project2_test.detail.vo;

public class ImageVO {
	private int img_FileNO;
	private String img_FileName;
	private int review_NO;
	private int rest_NO;

	public int getImg_FileNO() {
		return img_FileNO;
	}

	public void setImg_FileNO(int img_FileNO) {
		this.img_FileNO = img_FileNO;
	}

	public String getImg_FileName() {
		return img_FileName;
	}

	public void setImg_FileName(String img_FileName) {
		this.img_FileName = img_FileName;
	}

	public int getReview_NO() {
		return review_NO;
	}

	public void setReview_NO(int review_NO) {
		this.review_NO = review_NO;
	}

	public int getRest_NO() {
		return rest_NO;
	}

	public void setRest_NO(int rest_NO) {
		this.rest_NO = rest_NO;
	}

}
